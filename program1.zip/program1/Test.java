package program1;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Box box=new Box(10,20,30);
		System.out.println(box.volume());
	}

}
